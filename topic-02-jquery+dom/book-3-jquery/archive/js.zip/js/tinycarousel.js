$(document).ready(function()
{
	$('#slider1').tinycarousel();
});