var Hapi = require('hapi');
var Bell = require('bell');
var AuthCookie = require('hapi-auth-cookie');

var server = new Hapi.Server();

server.connection({ port: 4000 });

server.register([Bell, AuthCookie], function (err) {

    if (err) {
        console.error(err);
        return process.exit(1);
    }

    var authCookieOptions = {
        password: 'cookie-encryption-password-secure', // Password for encrypting the cookie
        cookie: 'my-auth', // Name of cookie to set
        isSecure: false
    };

    server.auth.strategy('my-cookie', 'cookie', authCookieOptions);

    var bellAuthOptions = {
        provider: 'twitter',
        password: 'twitter-encryption-password-secure', // Password for encrypting the cookie
        clientId: 'APPID_REPLACE_THIS', //'Your App Id',
        clientSecret: 'APP_SECRET_REPLACE_THIS', //'Your App Secret',
        isSecure: false
    };

    server.auth.strategy('twitter-oauth', 'bell', bellAuthOptions);

    server.auth.default('my-cookie');

    server.route([{
            method: 'GET',
            path: '/login',          // Login route where access is granted
            config: {
                auth: 'twitter-oauth',

                handler: function (request, reply) {
                    if (request.auth.isAuthenticated) {
                         request.cookieAuth.set(request.auth.credentials);
                        return reply('Hello ' + request.auth.credentials.profile.displayName);
                    }
                    reply('Not logged in...').code(401);
                }
            }
        }, {
            method: 'GET',
            path: '/account',    // Show the full profile shared with this app
            config: {
                handler: function (request, reply) {

                    reply(request.auth.credentials.profile);
                }
            }
    }, {
        method: 'GET',
        path: '/status',        // (twitter-specific) Show the most recent tweet
        config: {
            handler: function (request, reply) {

                reply("Your most recent tweet was: " + request.auth.credentials.profile.raw.status.text);
            }
        }
    }, {
            method: 'GET',
            path: '/',        // landing page after callback
            config: {
                auth: {
                    mode: 'optional'
                },
                handler: function (request, reply) {

                    if (request.auth.isAuthenticated) {
                        return reply('welcome back ' + request.auth.credentials.profile.displayName);
                    }
                    reply();
                }
            }
        }, {
            method: 'GET',
            path: '/logout',    // clear auth cookie
            config: {
                auth: false,
                handler: function (request, reply) {

                    request.cookieAuth.clear();
                    reply.redirect('/');
                }
            }
        }
    ]);
    server.start(function (err) {

        if (err) {
            console.error(err);
            return process.exit(1);
        }

       console.log('Server started at %s', server.info.uri);
    });
});
